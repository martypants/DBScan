
namespace DbscanImplementation
{
    public abstract class DatasetItemBase
    {
    }
}