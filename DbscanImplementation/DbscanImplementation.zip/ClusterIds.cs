
namespace DbscanImplementation
{
    public enum ClusterIds
    {
        Unclassified = 0,
        Noise = -1
    }
}