﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Oneview.Configuration;
using System.Data;
using System.Configuration; 


namespace Oneview.DataExtract.DatabaseAccess
{


    public class DataAccess
    {
        /// <summary>
        /// Use the Oneview dll to get the connection string from the DB
        /// </summary>
        /// <returns></returns>
        public static string GetOneviewManagementConnectionString()
        {
            // string holding the OneviewManagement DB.
            string managementDatabaseConnectionString = " " ; 
            
            try
            {
                //string connectionString = @"Data Source=OV-DUB-LTP-087.oneview-ire.local\ss_2014_dev;Initial Catalog=AdventureWorks2014;Integrated Security=true";
                /*    managementDatabaseConnectionString = new ConfigurationReader()
                    .ReadConfigurationSettings()
                    .ManagementDatabase;*/

                // get the connection string for the DB. 
                managementDatabaseConnectionString = ConfigurationManager.ConnectionStrings["OVManagementDB"].ConnectionString;
                // Check whether the connection string has been populated. 
                if (string.IsNullOrWhiteSpace(managementDatabaseConnectionString))
                {
                    Logger.LogException("main", "getting management DB Connection String", "Connection String to Management DB Empty", true);
                }
            }
            catch (Exception e)
            {
                Logger.LogException("main", "getting management DB", "unable to find connection string using registry" + e.ToString(), true);
            }

            

            return managementDatabaseConnectionString;
        }


        /// <summary>
        /// Query the database using a generic Query function. 
        /// </summary>
        /// <param name="queryString"></param>
        /// <param name="connectionString"></param>
        /// <returns></returns>
        public static SqlDataReader QueryDatabase(string connectionString, string queryString)
        {
            SqlConnection con = null; 

            try
            {
                con = new SqlConnection( GetConnectionString(connectionString));

                /*
                DbCommand command = con.CreateCommand();
                command.CommandText = queryString;*/

                // Open the connection.
                con.Open();

                SqlCommand cmd = new SqlCommand(queryString, con);

                Logger.LogException("DataAccess", "queryDatabase", "Queried " + queryString , false);

                return cmd.ExecuteReader();

            }
            catch (Exception e)
            {
                Logger.LogException("DataAccess", "queryDatabase", "Connecting to the Database" + e.ToString() , true );
            }
   
            // return an empty SQLDataReader
            return null;        
        }



        /// <summary>
        /// Query the database using a generic Query function. 
        /// </summary>
        /// <param name="queryString"></param>
        /// <param name="connectionString"></param>
        /// <returns></returns>
        public static SqlDataReader QueryDatabaseForExtract(string connectionString, string storedProcName, string dataExtractTableName, Int64 dataExtractLogId)
        {
            DbCommand command = null;
            try
            {
                // Create the command an
                command = CreateDBCommand(connectionString, storedProcName);

                SqlParameter pDataExtractTableName = new SqlParameter("@data_extract_table_name", SqlDbType.VarChar, 100) { Direction = ParameterDirection.Input, Value = dataExtractTableName };
                SqlParameter pDataExtractLogId = new SqlParameter("@data_extract_log_id", SqlDbType.BigInt) { Direction = ParameterDirection.Input, Value = dataExtractLogId };

                // add the parameters to the command object 
                command.Parameters.Add(pDataExtractTableName);                
                command.Parameters.Add(pDataExtractLogId);

                // Open the connection and execute the query.
                command.Connection.Open();
                command.ExecuteNonQuery();          

                Logger.LogException("DataAccess", "QueryDatabaseForExtract", string.Format( "table_name:{0} :data_extract_log_id : {1}:" , dataExtractTableName  ,  dataExtractLogId ), false);
                
                return (SqlDataReader)command.ExecuteReader();

            }
            catch (Exception e)
            {
                Logger.LogException("DataAccess", "QueryDatabaseForExtract", "Connecting to the Database" + e.ToString(), true);
            }

            // return an empty SQLDataReader
            return null;
        }



        /// <summary>
        ///  This job is going to update the log table in the database and also perform the extract. 
        /// DataExtractExecutionLog
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="extractLogStoredProc"></param>
        /// <param name="logStatus"></param>
        /// <param name="dataExtractTableName"></param>
        /// <param name="dataExtractBatchNumber"></param>
        /// <param name="exportFileName"></param>
        /// <param name="dataExtractLogId"></param>
        /// <param name="rowsWrittenToFile"></param>
        /// <returns></returns>
        public static Int64 CreateOrUpdateDatabaseExtractLog(string connectionString, string extractLogStoredProc, string logStatus , string dataExtractTableName , string dataExtractBatchNumber, string exportFileName, Int64 dataExtractLogId = 0 ,Int64 rowsWrittenToFile = 0 )
        {
            
            Int64 extractedLogId = 0;
            DbCommand command = null;

            try
            {
                command = CreateDBCommand( connectionString, extractLogStoredProc);

                // create the parameters with params that match the stored sproc. 
                SqlParameter pDataExtractTableName = new SqlParameter("@data_extract_table_name", SqlDbType.VarChar, 250) { Direction = ParameterDirection.Input , Value = dataExtractTableName } ;
                SqlParameter pDataExtractLogStatus = new SqlParameter("@data_extract_log_status", SqlDbType.VarChar, 50) { Direction = ParameterDirection.Input , Value = logStatus };
                SqlParameter pRowsWrittenToFile = new SqlParameter("@extracted_to_file_row_count", SqlDbType.BigInt) { Direction = ParameterDirection.Input, Value = rowsWrittenToFile };
                SqlParameter pDataExtractLogId = new SqlParameter("@data_extract_log_id", SqlDbType.BigInt ) { Direction = ParameterDirection.InputOutput , Value = dataExtractLogId };
                SqlParameter pDataExtractBatchNumber = new SqlParameter("@data_extract_batch_number", SqlDbType.VarChar, 2000) { Direction = ParameterDirection.Input, Value = dataExtractBatchNumber };
                SqlParameter pExportFileName = new SqlParameter("@export_file_name", SqlDbType.VarChar, 2000) { Direction = ParameterDirection.Input, Value = exportFileName };


                // add the parameters to the command object 
                command.Parameters.Add(pDataExtractTableName);
                command.Parameters.Add(pDataExtractLogStatus);
                command.Parameters.Add(pDataExtractLogId);
                command.Parameters.Add(pRowsWrittenToFile);
                command.Parameters.Add(pDataExtractBatchNumber);
                command.Parameters.Add(pExportFileName);
                
                // Open the connection and execute the query.
                command.Connection.Open();
                //run the query and export 
                command.ExecuteNonQuery();

                extractedLogId = (long)pDataExtractLogId.Value;

                //con.Close();
                Logger.LogException("DataAccess", "CreateOrUpdateDatabaseExtractLog", string.Format("table_name:{0} :log_status:{1} :data_extract_log_id:{2} rows_written_to_extract: {3} : batch{4} : filename{5} " , dataExtractTableName , logStatus , dataExtractLogId, rowsWrittenToFile , dataExtractBatchNumber , exportFileName) , false);
            }
            catch (Exception e)
            {
                Logger.LogException("DataAccess", "CreateOrUpdateDatabaseExtractLog", string.Format("table_name:{0} :log_status:{1} :data_extract_log_id:{2}  : rows_written_to_extract: {3}  : batch{4} : filename{5} : error{6} ", dataExtractTableName, logStatus, dataExtractLogId, rowsWrittenToFile, dataExtractBatchNumber, exportFileName ,  e.ToString() ) , true);
            }

            // return back the extract_log_id 
            return extractedLogId;
        }


        /// <summary>
        /// Create the command and open the connection to the DB. 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="storedProc"></param>
        /// <returns></returns>
        public static DbCommand CreateDBCommand(string connectionString , string storedProc)
        {
            SqlConnection con = null;
            DbCommand command = null;
            string dbConnectionString = null;

            try
            {

                dbConnectionString = GetConnectionString(connectionString);

                con = new SqlConnection(dbConnectionString);

                command = con.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = storedProc;
                command.CommandTimeout = 0;

            }
            catch (Exception e)
            {
                Logger.LogException("DataAccess", "CreateDBCommand", string.Format("connection_string:{0} :stored_proc:{1}  :error{2} ", connectionString, storedProc, e.ToString()), true);
            }
            return command;
        }


        /// <summary>
        /// Return back the connection string 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <returns></returns>
        public static string GetConnectionString(string connectionString)
        {
            if (!string.IsNullOrEmpty(connectionString))
                connectionString = GetOneviewManagementConnectionString();

            return connectionString; 
        }

        /// <summary>
        /// This function will return back a single list of values using the query. 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="query"></param>
        /// <returns></returns>
        public static List<string> GetSingleListOfValues(string connectionString, string query)
        {
            List<string> dataList = new List<string>();

            try
            {
                
                SqlDataReader datareader = QueryDatabase(connectionString, query);

                while (datareader.Read())
                {

                    for (int i = 0; i < datareader.FieldCount; i++)
                    {
                        dataList.Add(Convert.ToString(datareader.GetValue(i)));
                    }
                }

                datareader.Close();
            }                        
            catch (Exception e)
            {
                Logger.LogException(FolderFileChecks.GetCurrentMethod(), "GetSingleListOfValues", "Connecting to the Database" + query + e.ToString() , true );
            }
            return dataList;
        }



        public static Dictionary<string,string> GetSystemConfigValues(string connectionString, string query)
        {
            Dictionary<string, string> configValues = new Dictionary<string, string>();

            try
            {

                SqlDataReader datareader = QueryDatabase(connectionString , query);

                while (datareader.Read())
                {
                    string config_key = "";
                    string config_value = "";

                    config_key = (string)datareader["config_key"]; 
                    config_value = (string)datareader["config_value"]; 

                    configValues.Add(config_key , config_value);
                    
                }

                datareader.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("Issue connecting to the DB to get the config values "); 
                Logger.LogException("DataAccess:GetSystemConfigValues", "queryDatabase", "Issue getting config values" + query + e.ToString(), true);
            }
            return configValues;
        }

    }
}
